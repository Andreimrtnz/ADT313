<?php
echo "Hello World";
$age = 20;
$name = "John Andrei Martinez";

echo $age;
echo $name;

$x = 10;
$y = 50;

echo $age . "<br><strong>" . $name . " x+y=" .  $x+$y;
?>