<h1>Hands-on Activity</h1>

<?php
    $table = array(
        "header"=>array(
            "Firstname",
            "Middlename",
            "Lastname",
            "Section",
            "Course",
            "YearLevel",
        ),
        "body" =>
                 array(
                    "fistname"=>"FirstName",
                    "middlename"=>"Middlename",
                    "lastname"=>"Lastname",
                    "section"=>"Section",
                    "curse"=>"Course",
                    "yearlevel"=>"YearLevel"
                 ),
                 array(
                    "fistname"=>"FirstName",
                    "middlename"=>"Middlename",
                    "lastname"=>"Lastname",
                    "section"=>"Section",
                    "curse"=>"Course",
                    "yearlevel"=>"YearLevel"
                ),
        

                array(
                    "fistname"=>"FirstName",
                    "middlename"=>"Middlename",
                    "lastname"=>"Lastname",
                    "section"=>"Section",
                    "curse"=>"Course",
                    "yearlevel"=>"YearLevel"
                ),
        

                array(
                    "fistname"=>"FirstName",
                    "middlename"=>"Middlename",
                    "lastname"=>"Lastname",
                    "section"=>"Section",
                    "curse"=>"Course",
                    "yearlevel"=>"YearLevel"
                ),
        

                array(
                    "fistname"=>"FirstName",
                    "middlename"=>"Middlename",
                    "lastname"=>"Lastname",
                    "section"=>"Section",
                    "curse"=>"Course",
                    "yearlevel"=>"YearLevel"
                ),
        
        
                array(
                    "fistname"=>"FirstName",
                    "middlename"=>"Middlename",
                    "lastname"=>"Lastname",
                    "section"=>"Section",
                    "curse"=>"Course",
                    "yearlevel"=>"YearLevel"
                ),
        
        
                array(
                    "fistname"=>"FirstName",
                    "middlename"=>"Middlename",
                    "lastname"=>"Lastname",
                    "section"=>"Section",
                    "curse"=>"Course",
                    "yearlevel"=>"YearLevel"
                ),
        
        
                array(
                    "fistname"=>"FirstName",
                    "middlename"=>"Middlename",
                    "lastname"=>"Lastname",
                    "section"=>"Section",
                    "curse"=>"Course",
                    "yearlevel"=>"YearLevel"
                ),
        

                array(
                    "fistname"=>"FirstName",
                    "middlename"=>"Middlename",
                    "lastname"=>"Lastname",
                    "section"=>"Section",
                    "curse"=>"Course",
                    "yearlevel"=>"YearLevel"
                ),
        

                array(
                    "fistname"=>"FirstName",
                    "middlename"=>"Middlename",
                    "lastname"=>"Lastname",
                    "section"=>"Section",
                    "curse"=>"Course",
                    "yearlevel"=>"YearLevel"
                )
                );



                
        ?>
                
                <table border="1">
                <thead>  
                    
                
                <?php //for() { ?>
                        <th><?php //echo $value; ?></th>
                <?php  ?>
            
                <th>StudentID</th>
                <th><?php echo $table['header'][0] ?></th>
                    </thead>
                    </tbody>
                    <tr>
                        <td>123</td>
                        <th><?php echo $table['body'][0]['firstname']['MiddleName'][0]['firstname'] ?></td>
                        <th><?php echo $table['body'][0]['firstname']['MiddleName'][0]['firstname'] ?></td>
                    </tr>
                    </tbody>
                </table>





               