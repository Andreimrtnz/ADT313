<h1> switch</h1>
<?php
$role = "student"
switch (role){
    case 'student';
    echo "you are student, you are not allowrd to access to ...";
    break;
case 'instructor'
}

?>