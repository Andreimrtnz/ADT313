
<?php
    function generateUser() {
        
    }
?>