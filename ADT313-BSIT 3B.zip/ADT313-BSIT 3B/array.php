<?php
$cars = $array("volvo", "BMW", "toyota");
$cars = ["volvo", "BMW", "toyota"];

echo $cars[1];
