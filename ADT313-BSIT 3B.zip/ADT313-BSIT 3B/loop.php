<?php
    $colors = array("red", "green", "blue", "yellow");
    foreach




?>