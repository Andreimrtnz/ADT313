<?php
echo "Conditional statements<br/>";


$showVariable = true;
$name = "Lem";
$auth = false;

//if... else
if($showVariable == true) {
    echo $name;
} elseif ($showVariable && $name = 'lem' && &aunth) {
    echo "Hello ".$name;
  elseif($showVariable && $name $name){
    echo"not lem";
  }else{
 //no show
 echo "else statement";
  }
   
}

$showVariable == true ? $name :"short hand: else";
?>